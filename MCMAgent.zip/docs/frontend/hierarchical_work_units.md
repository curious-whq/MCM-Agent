# Recursive Hierarchical Work Units

This stage changes the static frontend's primary abstraction unit from an
event-centered slice to a recursively composable **Hierarchical Work Unit**.

The low-level event slice remains available, but it is now only an internal
analysis primitive used to recover event/state interaction and statement
ownership.

## Pipeline

```text
Whole FIRRTL
  ↓
physical module/instance hierarchy
  ↓
per-module boundary events
  ↓
register dependency SCCs
  ↓
event-centered cones
  ↓
Event-State Interaction Graph
  ↓
complexity + coupling driven partition
  ↓
Hierarchical Work Units
  ↓
coverage/ownership conservation
  ↓
child summary replacement plan
```

A physical module instance is always the preferred work-unit boundary. If the
module-local RTL remains too large, the same module can be recursively
partitioned into static regions.

## Event-State Interaction Graph

For every physical boundary event, the frontend computes both a full historical
cone and an immediate current-cycle frontier. The Event-State Interaction Graph
is built from the immediate frontier only; traversal stops at the first register
boundary. The resulting bipartite graph contains:

```text
Event → State SCC
State SCC → Event
```

An event-pair projection records:

- shared state SCCs;
- shared registers;
- shared static-cone statements;
- state Jaccard overlap;
- statement Jaccard overlap;
- a deterministic structural coupling score.

The score is a partition heuristic only. It does not assign semantic names or
claim a microarchitectural protocol relation.

## Partition rule

Crossing a LOC/signal/register/event/edge/statement limit only means:

```text
attempt_partition = true
```

It does **not** mean that a cut is automatically accepted.

The frontend accepts a cut only when the interaction graph exposes at least two
useful event groups with exclusive state/logic ownership. State or statements
touched by multiple children are promoted to the parent as shared glue.

Therefore:

```text
parent RTL
=
parent-local/shared RTL
+
disjoint child RTL
```

The same rule is applied recursively.

## Coverage ledger

Each same-module partition boundary conserves three categories:

```text
statements
concrete register state
events
```

Register SCCs are retained as coupling evidence and statistics, but recursive
ownership is tracked at concrete register-root granularity so a large feedback
SCC is not an artificial atomic boundary.

The ledger checks for:

```text
missing
duplicate
unsupported
```

A work unit is coverage-complete only when no item is silently lost or assigned
to multiple children.

## Child replacement

After a child is abstracted, its internal statement IDs are intentionally absent
from the parent analysis package. The parent receives only:

```text
summary_ref = umcm://<child-id>
boundary events
frontier/connection signals
```

plus the parent's own local RTL/state/events.

This is the static representation required for the later bottom-up flow:

```text
leaf RTL
  ↓
leaf µMCM
  ↓
parent-local RTL + child µMCM slots
  ↓
parent µMCM
```

No LLM is used in this stage.

## CLI

Install editable mode:

```bash
pip install -e .
```

Show the recursive hierarchy:

```bash
mcm-plan module-tree design.fir --root-module BoomMSHR
```

Show flat per-unit complexity:

```bash
mcm-plan module-stats design.fir --root-module LSU
```

Show coverage, interaction graph, parent-local ownership, and child-summary
replacement inputs:

```bash
mcm-plan module-plan design.fir \
  --root-instance 'TestHarness....dcache'
```

For experiments, structural limits can be overridden, for example:

```bash
mcm-plan module-plan design.fir \
  --root-module LSU \
  --max-statements 500 \
  --max-signals 2500 \
  --coupling-threshold 0.45
```

A concrete `--root-instance` is preferred for a whole-SoC FIRRTL. A
`--root-module` is useful while developing one LSQ/L1/L2 module type in
isolation.

## v8: immediate ownership instead of historical closure

Real BOOM `BoomMSHR` exposed an important failure mode in the first recursive
partitioner. A full backward event cone can cross register boundaries and then
follow the next-state history of a central FSM. Different boundary events may
therefore appear to share almost the entire module even when their *current-cycle*
state dependence is different.

v8 separates the two questions:

```text
full historical event cone
  -> retained for semantic extraction / future µMCM synthesis

immediate event-state frontier
  -> used only for ownership and WorkUnit partitioning
  -> backward traversal stops at the first register boundary
```

The interaction graph is now built from immediate registers and immediate
statements. Register SCCs remain reported as structural coupling evidence, but
are no longer atomic ownership units: a recursive WorkUnit may own only part of
one large SCC.

### Parent hub-state promotion

For event-rich modules, a register directly touched by a high fraction of
boundary events is marked as coordinator/hub state. Hub state is retained at the
parent and is not allowed to glue otherwise distinct event groups together.
The default structural rule is:

```text
module events >= 4
and register touches >= 3 events
and event fraction >= 0.60
    => parent hub state
```

This rule is intentionally disabled for two-event queue-like structures, where
shared enqueue/dequeue state is often the actual component identity.

### Pure combinational events

Events with no immediate register dependence are not discarded. Their immediate
statement cone participates in coupling/ownership, and sufficiently large
exclusive combinational cones may form children. Small or ambiguous cones remain
parent-local rather than being duplicated.

### Expected real-BOOM regression

The intended regression is:

```text
BoomProbeUnit
  -> remains manageable leaf

BranchKillableQueue
  -> remains strongly coupled leaf

BoomMSHR
  -> no longer becomes unsplittable merely because the historical cone reaches
     one central FSM SCC; hub/shared state stays at parent while local immediate
     state can seed multiple internal regions
```


## v9: scoped complexity + bounded ownership expansion

v8 fixed *partition discovery*: immediate state dependence can now separate
event groups below shared/hub coordinator state. Real `BoomMSHR` then exposed a
second failure mode: the tree could be structurally partitioned while most RTL
statements still remained at the parent, and tiny regions inherited inflated
whole-module dependency-edge counts.

v9 separates discovery from ownership explicitly:

```text
Stage A: discover child identity
  immediate Event-State frontier
  + hub promotion
  + coupling groups

Stage B: expand child ownership
  child events + child-owned state
  ↓
  bounded historical backward cone
  ↓
  may cross child-owned registers
  ↓
  STOP at every non-child register
```

This makes a parent/hub register an explicit **frontier value**, not an ownership
barrier for all logic that reads it. In particular:

```text
read parent/hub state
  -> allowed inside child as a frontier input

write parent/hub state
  -> parent-local

read peer-child state directly
  -> cross-child parent glue

write peer-child state
  -> parent-local
```

Statements selected by more than one child are also retained at the parent.
Coverage conservation remains exact after this expansion.

### Scope-aware complexity

Region edge complexity is no longer computed by counting every whole-module
edge that merely touches one region signal. For a non-module WorkUnit:

```text
statement-backed edge
  -> counted only if its statement belongs to the region

provenance-free alias/synthetic edge
  -> counted only if both endpoints are in the region signal scope
```

This prevents a five-statement region from being classified as oversized merely
because one signal has thousands of aliases/fanout edges elsewhere in the
module.

### Primary v9 regression metric

For a successfully partitioned module, the important metric is no longer just:

```text
decision = partitioned
```

but also:

```text
parent_local_statements / total_statements
```

The ratio should fall materially while all conservation checks remain true:

```text
coverage.complete = true
missing_statement_ids = []
duplicate_statement_ids = []
missing_event_ids = []
duplicate_event_ids = []
```

This is the condition required before child µMCM summaries can actually reduce
the parent analysis input.
